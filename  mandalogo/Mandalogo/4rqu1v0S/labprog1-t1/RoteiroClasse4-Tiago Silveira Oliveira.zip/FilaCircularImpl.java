package roteiroClasse4;

public class FilaCircularImpl implements FilaCircular {
	private int apont;
	private int cabeca;
	private int[] fila;
	
	/**
	 * fila cheia
	 * @param fila
	 * @return
	 */
	private static boolean estaCheia(int[] fila) {
		int param = 0;
		for (int i = 0; i < fila.length; i++) {
			if (fila[i] != 0) param++;
		}
		if (param == fila.length) return true;
		return false;
	}
	
	/**
	 * esta vazia
	 * @param fila
	 * @return
	 */
	private static boolean estaVazia(int[] fila) {
		int param = 0;
		for (int i = 0; i < fila.length; i++) {
			if (fila[i] == 0) param++;
		}
		if (param == fila.length) return true;
		return false;
	}
	
	public FilaCircularImpl(int capacidadeDaFila) {
		apont = 0;
		cabeca = 0;
		fila = new int[capacidadeDaFila];
	}

	@Override
	public boolean inserir(int elemento) {
		if (elemento < 0) return false; // elemento negativo
		if (estaCheia(this.fila)) return false; // inserir em fila cheia
		fila[apont] = elemento;
		apont++;
		return true;
	}

	@Override
	public int remover() {
		int removido = 0;
		
		if (estaVazia(this.fila)) return -1; // fila vazia
		removido = this.fila[cabeca];
		this.fila[cabeca] = 0;
		if (cabeca++ == this.fila.length) {
			cabeca = 0;
		} else {
			cabeca++;
		}
		return removido;
	}

	@Override
	public int inicioFila() {
		if (estaVazia(this.fila)) return -1; //fila vazia
		if (cabeca == 0) {
			return this.fila[cabeca];
		}
		return this.fila[cabeca-1];
	}

	@Override
	public int fimFila() {
		if (estaVazia(this.fila)) return -1; // fila vazia
		if (cabeca == (this.fila.length -1)) { // apontador no ultimo lugar da fila
			return this.fila[0];
		} else if (cabeca == 0){ // apontador no comeco da fila
			return this.fila[this.fila.length - 1];
		} else {
			if (cabeca != 0) {
				return this.fila[cabeca+1];
			}
			return this.fila[cabeca -1];
		}
	}

	@Override
	public int tamanhoAtualFila() {
		int tamFila = 0;
		for (int i = 0; i < fila.length; i++) {
			if (fila[i] != 0) tamFila++;
		}
		return tamFila;
	}
	
	public String toString() {
		String palavra = "[";
		if (estaVazia(this.fila)) return "[]";
		for (int i = 0; i < this.fila.length; i++) { 
			if ((i+1) ==this.fila.length ) { // colchete no fim da fila
				palavra = palavra+this.fila[i];
				break;
			}
			palavra = palavra+this.fila[i]+" ";
			if (this.fila[i] == 0) {
				palavra = "["+palavra.substring(3);
			}
		}
		palavra = palavra+"]";
		return palavra;
	}

}
